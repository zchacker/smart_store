<h1 class="text-center">Make it, wear it, be authentic</h1>
<div class="container">
  <div class="row">
    <br>
    <br>
    <br>
  </div>
  <div class="row">
    <div class="col-md-4 text-center">
      <div class="choice_wraper">
        <a href="<?=base_url();?>index.php/design/upload_photo" class="btn btn-primary" >Upload your design</a>
      </div>
    </div>
    <div class="col-md-4 text-center">
      <div class="choice_wraper">
        <a href="<?=base_url();?>index.php/design/drow" class="btn btn-primary" >Draw your dress design now</a>
      </div>
    </div>
    <div class="col-md-4 text-center">
      <div class="choice_wraper">
        <a href="<?=base_url();?>index.php/design/designers" class="btn btn-primary" >Chooce the painter</a>
      </div>
    </div>
  </div>
</div>
