<div class="container">
  <h2 class="text-center"> Thank you </h2>
  <strong>Your order NO: <?=$order_id?></strong>
</div>
